package com.training.movieratingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRatingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
